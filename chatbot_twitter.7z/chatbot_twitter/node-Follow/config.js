
module.exports = {
	consumer_key: 'RJYKFipMgNnwrFj63WaG1h0CI',
	consumer_secret: '1iISLNx1slKBzJtoyjFSJ2g9hPZzbJUgAllEFjOqKJk9A80aVk',
	access_token: '929348089856524293-3jOe3mbj0D1bDyaMRyihi6CkfdtjKt7',
	access_token_secret: 'hvo6UpLSHo9EQKbUPdefUisTSxIRkyDbBY2qHlwJeCgR4'
}